package pkg_prod;

import java.util.Scanner;

import proj_begin.Mainpage;

public class Toy extends Product {
	Product[] p;
	Scanner sc = new Scanner(System.in);
	public void toyMenu() {
		
		System.out.println("Choose the task to perform:- ");
		System.out.println("1].Add toy details.");
		System.out.println("2].View all toys.");
		System.out.println("3].Search toy by it's Id.");
		System.out.println("4].Bill of toy with discounted price");
		System.out.println("5].Return to main page.");
		int choose = sc.nextInt();
		switch(choose) {
		case 1:
			addToys();
			break;
		case 2:
			viewAllToys();
			break;
		case 3:
			System.out.println("Enter id number of toy:- ");
			int id = sc.nextInt();
			searchToyById(id);
			break;
		case 4:
			System.out.println("Enter id number of toy:- ");
			int idt = sc.nextInt();
			calculateDiscount(idt);
			break;
		case 5:
			Mainpage.mainOption();
			break;
		}
	}
	public void addToys() {
		p = new Product[5];
		
		System.out.println("Enter the number of Toys to add:- ");
		int opt = sc.nextInt();
		for(int i=0;i<opt;i++) {
			System.out.println("Enter the Toy Id :- ");
			int prodId = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter the name of Toy to add:- ");
			String prodName = sc.next();
			System.out.println("Enter the stock available of Toys :- ");
			int stock_avail =sc.nextInt(); 
			sc.nextLine();
			System.out.println("Enter the price of Toy:- ");
			double price = sc.nextDouble();
			sc.nextLine();
			System.out.println("Enter the Toy description :- ");
			String prod_descr = sc.nextLine();
			p[i] = new Product(prodId,prodName,stock_avail,price,prod_descr);	
		}
		toyMenu();
	}
	public void viewAllToys() {
		for(Product pro:p) {
			if(pro !=null) {
			System.out.println(pro);
			}
		}
		toyMenu();
	}
	public void calculateDiscount(int prodId) {
		for(Product prod:p) {
			if(prod.getProdId()==prodId) {
				System.out.println("Please Enter your age:- ");
				int age = sc.nextInt();
				sc.nextLine();
				if(age<2 && age>4) {
					double discount = (0.15*prod.getPrice());
					double new_price = (prod.getPrice()-discount);
					System.out.println(prod.toString()+"  "+"Discount:- "+"---->"+discount+" "
							+"Discounted_Price:- "+"---->"+new_price);
				}
				else if(age>=4 && age<5) {
					double discount = (0.05*prod.getPrice());
					double new_price = (prod.getPrice()-discount);
					System.out.println(prod.toString()+"  "+"Discount:- "+"---->"+discount+" "
							+"Discounted_Price:- "+"---->"+new_price);
				}else if(age>=5) {
					
					System.out.println(prod.toString()+"  "+"Discount:- Sorry no discount available for you....! ");
				}
				
				
			}
		}
		toyMenu();
	}
	
	public Product searchToyById(int prodId) {
		for(Product product:p) {
			if(product.getProdId()==prodId) {
				return product;
				//toyMenu();
			}
			else {
				System.out.println("Sorry required toy details not found....");
				toyMenu();
			}
		}
		return null;
	}

}
