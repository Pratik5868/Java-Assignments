package pkg_prod;

public class Product {
	private int prodId;
	private String prodName;
	private int stock_avail;
	private double price;
	private String prod_descr;
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public int getStock_avail() {
		return stock_avail;
	}
	public void setStock_avail(int stock_avail) {
		this.stock_avail = stock_avail;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getProd_descr() {
		return prod_descr;
	}
	public void setProd_descr(String prod_descr) {
		this.prod_descr = prod_descr;
	}
	public Product(int prodId, String prodName, int stock_avail, double price, String prod_descr) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
		this.stock_avail = stock_avail;
		this.price = price;
		this.prod_descr = prod_descr;
	}
	public Product() {
		super();
		
	}
	@Override
	public String toString() {
		return "prodId ---->" + prodId + ", prodName---->" + prodName + ", stock_avail---->" + stock_avail + 
				", price---->"+ price + ", prod_descr---->" + prod_descr;
	}
	

}
