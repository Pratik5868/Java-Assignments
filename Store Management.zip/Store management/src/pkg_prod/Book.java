package pkg_prod;

import java.util.Scanner;

import proj_begin.Mainpage;

public class Book extends Product{
	Product[] p1;
	Scanner sc = new Scanner(System.in);
	public void bookMenu() {
		System.out.println("<------------------------------------------------->");
		System.out.println("Choose the task to perform:- ");
		System.out.println("1].Add Book details.");
		System.out.println("2].View all books.");
		System.out.println("3].Search book by it's Id.");
		System.out.println("4].Bill of book with discounted price");
		System.out.println("5].Return to main page.");
		int choose = sc.nextInt();
		switch(choose) {
		case 1:
			addBooks();
			break;
		case 2:
			viewAllBooks();
			break;
		case 3:
			System.out.println("Enter id number of Book:- ");
			int id = sc.nextInt();
			searchBookById(id);
			break;
		case 4:
			System.out.println("Enter id number of Book:- ");
			int idt = sc.nextInt();
			calculateDiscount(idt);
			break;
		case 5:
			Mainpage.mainOption();
		}
	}
	public void addBooks() {
		p1 = new Product[5];
		System.out.println("<------------------------------------------------->");
		System.out.println("Enter the number of Books to add:- ");
		int opt = sc.nextInt();
		for(int i=0;i<opt;i++) {
			System.out.println("Enter the Book Id :- ");
			int prodId = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter the name of Book to add:- ");
			String prodName = sc.nextLine();
			System.out.println("Enter the stock available of Book :- ");
			int stock_avail =sc.nextInt(); 
			sc.nextLine();
			System.out.println("Enter the price of Book:- ");
			double price = sc.nextDouble();
			sc.nextLine();
			System.out.println("Enter the Book description :- ");
			String prod_descr = sc.nextLine();
			System.out.println("<------------------------------------------------->");
			p1[i] = new Product(prodId,prodName,stock_avail,price,prod_descr);	
		}
		bookMenu();
	}
	public void viewAllBooks() {
		for(Product pro:p1) {
			if(pro !=null) {
			System.out.println(pro);
			}
		}
		bookMenu();
	}
	public void calculateDiscount(int prodId) {
		for(Product prod:p1) {
			if(prod.getProdId()==prodId) {
				double discount = (0.1*prod.getPrice());
				double new_price = (prod.getPrice()-discount);
				System.out.println("<--------------------------Bill of Toy-------------------------->");
				System.out.println(prod.toString()+"  "+"Discount:- "+"---->"+discount+" "
						+"Discounted_Price:- "+"---->"+new_price);
			}
		}
	}

	
	public Product searchBookById(int prodId) {
		for(Product product:p1) {
			if(product.getProdId()==prodId) {
				return product;
				//bookMenu();
			}
			else {
				System.out.println("Sorry required Book details not found....");
				bookMenu();
			}
		}
		return null;
	}

}
