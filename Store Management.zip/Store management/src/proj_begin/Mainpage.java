package proj_begin;
import java.util.Scanner;

import pkg_prod.Book;
import pkg_prod.Toy;
public class Mainpage {
	public static void mainOption() {
		try (Scanner s2 = new Scanner(System.in)) {
			System.out.println("Please choose the product to view it's details:- ");
			System.out.println("1]Toys");
			System.out.println("2]Books");
			System.out.println("3]Exit");
			int option = s2.nextInt();
			switch(option) {
			case 1:
				Toy t = new Toy();
				t.toyMenu();
				break;
			case 2:
				Book b = new Book();
				b.bookMenu();
				break;
			case 3:
				System.out.println("Good Bye.........!");
				Runtime.getRuntime().exit(0);
				break;
			}
		}
	}
}
