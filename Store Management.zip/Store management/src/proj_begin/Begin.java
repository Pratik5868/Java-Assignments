package proj_begin;

import java.util.Scanner;

public class Begin {
	
	public static void main(String[] args) {
		Scanner s1 = new Scanner(System.in);
		System.out.println("---------------------Store Manager------------------------");
		System.out.println("Please enter username:- ");
		String username = s1.next();
		s1.nextLine();
		System.out.println("Please enter password:- ");
		String password = s1.next();
		s1.nextLine();
		if(username.equalsIgnoreCase("shree")&&password.equalsIgnoreCase("1234")) {
			Mainpage.mainOption();
		}
		else {
			System.out.println("Username and Password is incorrect......!");
		}
	}

}
