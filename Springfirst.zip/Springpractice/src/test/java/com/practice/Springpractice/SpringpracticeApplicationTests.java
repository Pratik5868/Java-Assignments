package com.practice.Springpractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringpracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
