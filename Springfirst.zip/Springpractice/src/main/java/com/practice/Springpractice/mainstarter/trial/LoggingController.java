package com.practice.Springpractice.mainstarter.trial;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class LoggingController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	//Sending two or more parameters from the URL-path  to the controller 
	@GetMapping("/loginfromuser/{username}/{password}")
	public String getHello(@PathVariable String username,@PathVariable String password) {
		//logger.info(username);
		logger.debug(username);
		System.out.println("Username:- "+username+" "+"Password:- "+password);
		return "hello";
	}

}
