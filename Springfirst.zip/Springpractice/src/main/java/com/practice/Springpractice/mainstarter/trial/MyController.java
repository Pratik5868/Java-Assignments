package com.practice.Springpractice.mainstarter.trial;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class MyController {
	
	
	@GetMapping("/getLogin")
	public String gotoLogin() {
		return "login";
	}
	
	@GetMapping("/logininput")
	
	public String getHello(@RequestParam String username,@RequestParam String password) {
		
		System.out.println("Username:- "+username+" "+"Password:- "+password);
		return "hello";
	}

}
