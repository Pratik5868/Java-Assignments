package exam.menu;
import java.util.*;

import exam.manager.GameManagement;
import exam.trial.Game;
public class GameMenu {
	public void displayMenu() {
		System.out.println("------------------Welcome to game Menu-------------------");
		System.out.println("PLease choose an option below:- ");
		System.out.println("1]Add Game");
		System.out.println("2]Display Game");
		System.out.println("3]Exit");
		Scanner s =new Scanner(System.in);
		int choice =s.nextInt();
		GameManagement g  = new GameManagement();
		switch(choice) {
		case 1 :
			g.addGame();
			break;
		case 2:
			g.displayGameSchedule();
			break;
		case 3:
			System.exit(choice);
			
		}
	}
    
}
