package exam.menu;

import java.util.Scanner;

import exam.manager.PlayerManagement;

public class PlayerMenu {
	public void displayMenu() {
		System.out.println("------------------Welcome to Player Menu-------------------");
		System.out.println("PLease choose an option below:- ");
		System.out.println("1]Add Player");
		System.out.println("2]Display Player");
		System.out.println("3]Exit");
		Scanner s =new Scanner(System.in);
		int choice =s.nextInt();
		PlayerManagement g  = new PlayerManagement();
		switch(choice) {
		case 1 :
			g.addPlayer();
			break;
		case 2:
			g.displayPlayerSchedule();
			break;
		case 3:
			System.exit(choice);
			
		}
	}

}
