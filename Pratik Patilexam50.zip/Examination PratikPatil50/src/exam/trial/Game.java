package exam.trial;

public class Game {
	public int gameId;
	public String gameName;
	public Player p;
	public String gameDay;
	public Game() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Game(int gameId, String gameName, Player p, String gameDay) {
		super();
		this.gameId = gameId;
		this.gameName = gameName;
		this.p = p;
		this.gameDay = gameDay;
	}
	@Override
	public String toString() {
		return "Game [gameId=" + gameId + ", gameName=" + gameName + ", p=" + p + ", gameDay=" + gameDay + "]";
	}
	public int getGameId() {
		return gameId;
	}
	public void setGameId(int gameId) {
		this.gameId = gameId;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public Player getP() {
		return p;
	}
	public void setP(Player p) {
		this.p = p;
	}
	public String getGameDay() {
		return gameDay;
	}
	public void setGameDay(String gameDay) {
		this.gameDay = gameDay;
	}
	

}
