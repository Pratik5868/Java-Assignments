package exam.trial;

public class Player {
	public int playerNo;
	public String playerName;
    public String teamName;
    public Game g;
    
	public Player(int playerNo, String playerName, String teamName, Game g ) {
		super();
		this.playerNo = playerNo;
		this.playerName = playerName;
		this.teamName = teamName;
		this.g = g;
		
	}
	public Player() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Player [playerNo=" + playerNo + ", playerName=" + playerName + ", teamName=" + teamName + ", g=" + g
				+"]";
	}
	public int getPlayerNo() {
		return playerNo;
	}
	public void setPlayerNo(int playerNo) {
		this.playerNo = playerNo;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public Game getG() {
		return g;
	}
	public void setG(Game g) {
		this.g = g;
	}
	
	
    

}
