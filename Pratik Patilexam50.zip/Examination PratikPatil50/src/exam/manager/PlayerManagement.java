package exam.manager;

import exam.trial.Game;
import exam.trial.Player;
import java.util.*;
public class PlayerManagement {
	Player[] p = new Player[5];
	Game[] g = new Game[5];
	public void addPlayer() {
		Scanner s1 = new Scanner(System.in);
		System.out.println("Please enter number of players to add:- ");
		int limit  = s1.nextInt();
		for(int i =0;i<limit;i++ ) {
			System.out.println("Please enter  playersNo.:- ");
			int num = s1.nextInt();
			s1.nextLine();
			System.out.println("Please enter  playerName  to add:- ");
			String pn = s1.nextLine();
			
			System.out.println("Please enter team name to add:- ");
			String tn = s1.nextLine();
			
			System.out.println("Please enter  game details to add:- ");
			GameManagement g1 = new GameManagement();
			g1.addGame();
			
			p[i] = new Player(num,pn,tn,null);
		}
	}
	public void displayPlayerSchedule() {
		for(Player p1 : p) {
			System.out.println(p1);
		}
	}

}
