package exam.manager;

import java.util.Scanner;

import exam.trial.Game;
import exam.trial.Player;


public class GameManagement {
	Game[] gp;
	public void addGame() {
		Scanner s1 = new Scanner(System.in);
		System.out.println("Please enter number of games to add:- ");
		int limit  = s1.nextInt();
		for(int i =0;i<limit;i++ ) {
			System.out.println("Please enter  game-id.:- ");
			int num = s1.nextInt();
			System.out.println("Please enter  gameName  to add:- ");
			String pn = s1.nextLine();
			System.out.println("Please enter player name to add:- ");
			Player g = new Player();
			System.out.println("Please enter game day to add:- ");
			String gd = s1.nextLine();
			gp[i] = new Game(num,pn,g,gd);
		}
	}
	public void displayGameSchedule() {
		for(Game g : gp) {
			System.out.println(g);
		}
	}
}
