package exam.startproject;
import java.util.*;

import exam.menu.GameMenu;
import exam.menu.PlayerMenu;
public class Starter {

	public static void main(String[] args) {
		System.out.println("-------------------------------Welcome to Sports Scheduler------------------------------");
        System.out.println("Please select following option to perform task:- ");
        System.out.println("1]PLAYER MENU");
        System.out.println("2]GAME MENU");
        System.out.println("3]EXIT");
        Scanner sc =new Scanner(System.in);
        int choice = sc.nextInt();
        switch(choice) {
        case 1:
        	PlayerMenu p = new PlayerMenu();
        	p.displayMenu();
        	break;
        case 2:
        	GameMenu g = new GameMenu();
        	g.displayMenu();
        	break;
        case 3:
            System.exit(choice);
        }
	}

}
